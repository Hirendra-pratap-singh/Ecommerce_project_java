# E-Commerce Store Java Project
This is a java project that applies principles of object oriented programming in creating the different functionalities of a common e-commerce store. The store has 3 main users - customer, seller and admin. Different functions for each such as view products and subproducts, add to cart and checkout functionalities for the customer ; add products under different subcategories for the seller and view customer and seller products, contact customer and seller functionalities for admin. 

## How to run the project
Download the E-Commerce folder and then open it up in your IDE. Locate the store.java file within store subfolder and run it as Java application.  
