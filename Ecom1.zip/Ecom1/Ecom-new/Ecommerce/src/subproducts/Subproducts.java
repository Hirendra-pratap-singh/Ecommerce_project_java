package subproducts;
import store.Product;

public interface Subproducts {
    public Product[] getListOfProducts();
    public Product[] setListOfProducts();
}
